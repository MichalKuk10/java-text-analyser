import java.io.File;
import java.io.FileNotFoundException;

import java.util.Iterator;
import java.util.Scanner;


class Main {

    static String fileName;
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) throws FileNotFoundException {

        FileContent fileContent = new FileContent("/home/michal/Desktop/Codecool/Java/java-text-analyser/java-text-analyse/testowy.txt");
        
        // StatisticalAnalysis charAnalysis = new StatisticalAnalysis(fileContent.charIterator());
        StatisticalAnalysis statisticalAnalysis = new StatisticalAnalysis(fileContent.wordIterator());

       System.out.println(statisticalAnalysis.countOf("dupa"));
        
     }
}