import java.util.List;
import java.util.Map;

public class View {


public static void print(int number){

    System.out.println(number);
}

public static void print(String string){

    System.out.println(string);
}

public static void print(List<String> list){

    System.out.println(list);
}

public static void print(Map<String, Integer> map) {

    System.out.println(map);
}

}